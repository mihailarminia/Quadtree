#!/bin/bash

zip Arminia.Mihail Makefile main.c functions.h task01.c task02.c task03.c matrix.c count.c create.c h_and_v.c bfs.c other_functions.c bonus.c README